package com.example.responsi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent
import android.annotation.SuppressLint

class RegisterActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val backRegisterButton: Button = findViewById(R.id.imageButton)
        backRegisterButton.setOnClickListener {
            val intentToMain = Intent(this, MainActivity::class.java)
            startActivity(intentToMain)
        }
        val registerButton: Button = findViewById(R.id.register_btn)
        registerButton.setOnClickListener {
            val intentToHome = Intent(this, HomeActivity::class.java)
            startActivity(intentToHome)
        }
    }

}