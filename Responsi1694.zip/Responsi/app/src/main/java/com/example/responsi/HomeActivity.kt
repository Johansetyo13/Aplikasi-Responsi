package com.example.responsi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentTransaction

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val fragmentHome = FragmentResponsi
        val fragment = supportFragmentManager.findFragmentByTag(FragmentResponsi::class.java.simpleName)

        if (fragment !is FragmentResponsi){
            supportFragmentManager.beginTransaction()
                .add(R.id.action_container, fragmentHome, FragmentResponsi::class.java.simpleName)
                .commit()
        }
    }
}
private fun Unit.commit() {
    TODO("Not yet implemented")
}

private fun FragmentTransaction.add(actionContainer: Int, fragmentHome: FragmentResponsi.Companion, simpleName: String) {

}