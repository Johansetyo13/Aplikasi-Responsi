package com.example.responsi

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.content.Intent

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//membuataksihomeactivitymelaluiloginbutton
        val loginButton: Button = findViewById(R.id.login_btn)
        loginButton.setOnClickListener {
            val intentToHome = Intent(this, HomeActivity::class.java)
            startActivity(intentToHome)
        }
        val forPassButton: Button = findViewById(R.id.reset_pass_btn)
        forPassButton.setOnClickListener {
            val intentToRecovery = Intent(this, RecoveryActivity::class.java)
            startActivity(intentToRecovery)
        }
        val signUpButton: Button = findViewById(R.id.signup_btn)
        signUpButton.setOnClickListener {
            val intentToRegister = Intent(this, RegisterActivity::class.java)
            startActivity(intentToRegister)
        }
    }
}